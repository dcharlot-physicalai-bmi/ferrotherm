import os, pathlib, json, time, subprocess, datetime
root=pathlib.Path.home()/"bench-scratch"
repo=root/"ferrotherm-thrml"
energy_paths=[pathlib.Path("/sys/class/powercap/intel-rapl:0"),pathlib.Path("/sys/class/powercap/intel-rapl:0:0")]
domains=[{"path":str(p),"name":(p/"name").read_text().strip(),"max_energy_range_uj":int((p/"max_energy_range_uj").read_text())} for p in energy_paths]
(root/"rapl-domains.json").write_text(json.dumps(domains,indent=2))
trace=open(root/"rapl-raw.jsonl","w",buffering=1)
events=open(root/"rapl-events.jsonl","w",buffering=1)
def event(kind,**kw):
 d={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"monotonic":time.monotonic(),"kind":kind,**kw};events.write(json.dumps(d)+"\n");print(d,flush=True)
previous={}
def sample(phase,trial):
 row={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"monotonic":time.monotonic(),"phase":phase,"replicate":trial,"loadavg":os.getloadavg()}
 for d in domains:
  now=int((pathlib.Path(d["path"])/"energy_uj").read_text());key=d["name"];row[key+"_uj"]=now
  if key in previous:
   row[key+"_delta_uj"]=(now-previous[key])%d["max_energy_range_uj"]
   row[key+"_wrapped"]=now<previous[key]
  previous[key]=now
 trace.write(json.dumps(row)+"\n")
def window(seconds,phase,trial):
 end=time.monotonic()+seconds
 while time.monotonic()<end:sample(phase,trial);time.sleep(.1)
try:
 for trial in range(5):
  event("quiet_wait_start",replicate=trial,threshold=2.0,max_wait_seconds=180)
  deadline=time.monotonic()+180
  while os.getloadavg()[0]>2.0 and time.monotonic()<deadline:sample("quiet_wait",trial);time.sleep(1)
  load=os.getloadavg()[0]
  if load>2.0:
   event("quiet_gate_refused",replicate=trial,load1=load);break
  event("quiet_gate_passed",replicate=trial,load1=load)
  window(5,"external_baseline_before",trial)
  out=root/("framework128-run-"+str(trial))
  cmd=[str(repo/"target/release/ferrotherm-thrml-bench"),"--out",str(out),"--trials","5","--python",str(root/"thrml-venv/bin/python")]
  event("harness_start",replicate=trial,command=cmd)
  with open(root/("harness-"+str(trial)+".log"),"w") as log:
   env=dict(os.environ,JAX_PLATFORMS="cpu")
   proc=subprocess.Popen(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,env=env)
   while proc.poll() is None:sample("mixed_harness",trial);time.sleep(.1)
  event("harness_end",replicate=trial,exit_code=proc.returncode)
  window(5,"external_baseline_after",trial)
  if proc.returncode!=0:break
 event("driver_finished")
 (root/"driver-exit.txt").write_text("0\n")
finally:trace.close();events.close()
