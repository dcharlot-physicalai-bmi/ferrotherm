# Correct Framework host follow-up — 7 November 2026

Machine 94655143-44cb-4c99-a72a-a988f4af51e9 is confirmed as framework-128gb-0000, 32 CPUs. The previous Framework findings in SUMMARY.md concern the incorrectly labelled primary ID, not this host.

The correct host has rootless-readable RAPL package and core counters. Both max_energy_range_uj values are 65,532,610,987. The pinned e92c9fc1a263ad52862105e05175ef83e2ba7796 build succeeded with user Rust and THRML 0.1.4 / JAX 0.12.0.1 CPU in a user Python 3.13.16 venv.

From 6:57:03–7:00:03 AM EST the wrapper waited for the unchanged load1<=2 quiet gate. It never passed: observed load1 2.125–2.456543. No idle baseline, harness invocation, or benchmark trial was started. No gate was weakened or other workload stopped.

| Workload | Samplers | Gross benchmark J | Incremental J | J/effective sample | 95% energy CI |
|---|---|---|---|---|---|
| thrml_readme_ising_chain_n5 | ferrotherm / THRML | unavailable | unavailable | unavailable | unavailable |
| ising_grid2d_open_3x3 | ferrotherm / THRML | unavailable | unavailable | unavailable | unavailable |
| potts_path_q3_n6 | ferrotherm / THRML | unavailable | unavailable | unavailable | unavailable |
| tsp_iv4_three_body_d8 | ferrotherm / THRML | unavailable | unavailable | unavailable | unavailable |

RAPL read-path verification: 180 raw samples over 179.075677 seconds captured one package-counter wrap. Wrap-corrected host observation was 6,668.750907 package joules and 29.910516 core joules. These are busy-host observations during the wait, NOT benchmark energy, NOT an idle baseline, and NOT a sampler comparison. Core is a subdomain: do not sum package and core.

The wrapper planned five harness repetitions, each with five accuracy trials, but none ran. Even if quiet, the pinned harness only meters a separate >=2s repeat of its first ferrotherm workload. It does not meter THRML or scored chains, does not interleave the samplers, and intentionally leaves J/effective sample null. No per-workload energy or CI is supported.

framework128/ contains raw counters, ranges, wrap flags/deltas, quiet-gate events, setup log, exact measurement driver, software/hardware provenance, and structured summary. No sudo or configuration changes were used. The driver exited; no benchmark process remains.
